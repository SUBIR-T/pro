# ToolDex & Security Hub

A dual-purpose security portal built for learning and demonstration:

1. **Tool Discovery & Risk Engine** — search any security tool/command and get both a beginner and a professional-level explanation, a risk classification, legal disclaimers where relevant, safe alternatives, and copyable example commands for use in your own lab.
2. **Threat Intelligence & Incident Archive** — a live security-news feed, structured breach post-mortems (attack vector → root cause → impact → legal outcome), and on-demand CVE / CISA KEV lookup.

**[Live demo →](#)** *(replace with your deployed GitHub Pages / hosting URL once live)*

![screenshot](og-image.png)
*(replace `og-image.png` with an actual screenshot — this filename is already wired into the page's social-preview meta tags)*

---

## Status

This repo currently ships the **frontend prototype** (`index.html`) — a fully interactive dark-mode UI running on mock/in-memory data, so the design and UX can be reviewed before the backend is wired in. A FastAPI + SQLAlchemy backend (real tool database, live RSS ingestion, NVD/CISA KEV API integration, JWT auth) is the next milestone — see [Roadmap](#roadmap).

## Features (current prototype)

- Tool search with live filtering across tools, news, incidents, and CVEs from a single search bar
- Beginner / Professional explanation toggle per tool
- Risk badges (low / medium / high) with legal disclaimers on higher-risk tools
- Safe-alternative suggestions for riskier tools
- Copyable example commands, clearly scoped to "your own authorized lab" use
- Structured incident post-mortems in a consistent 4-part format
- CVE/KEV search with CVSS scoring and exploited-in-the-wild flags
- Donation section (UPI + BTC) — config lives in one place near the top of the `<script>` block

## Tech (planned full stack)

| Layer      | Choice                                             |
|------------|-----------------------------------------------------|
| Backend    | Python — FastAPI                                    |
| Database   | SQLite + SQLAlchemy                                 |
| Frontend   | Jinja2 templates + Tailwind CSS (prototype: static HTML) |
| Ingestion  | `feedparser` (RSS), `httpx` (NVD/CISA KEV APIs)     |
| Auth       | JWT / session-based                                 |
| Deploy     | Docker + docker-compose                             |

## Running the prototype locally

No build step — it's a single static HTML file.

```bash
# Option 1: just open it
open index.html   # macOS
start index.html  # Windows
xdg-open index.html  # Linux

# Option 2: serve it (recommended, avoids browser file:// restrictions)
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploying to GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under "Build and deployment", set **Source: Deploy from a branch**, branch: `main`, folder: `/ (root)`.
4. Save — your site will be live at `https://<your-username>.github.io/<repo-name>/` within a minute or two.

## Configuring your own donation info / profile links

Both live in clearly marked config blocks near the bottom of the `<script>` tag in `index.html`:

```javascript
const DONATION = {
  upiId: "your-upi-id@bank",
  payeeName: "Your Name",
  btcAddress: "your-btc-address"
};

const PROFILE_LINKS = {
  github: "https://github.com/your-username",
  linkedin: "https://linkedin.com/in/your-username",
  portfolio: ""  // leave blank to hide
};
```

## Roadmap

- [ ] FastAPI backend with the `Tools`, `Users`, `NewsArticles`, `Incidents` SQLAlchemy models
- [ ] Real RSS ingestion (The Hacker News, BleepingComputer, KrebsOnSecurity, CISA Alerts)
- [ ] Live NVD CVE search + CISA KEV catalog sync
- [ ] JWT auth, saved tools/articles, search history
- [ ] Dockerfile + docker-compose + run.sh / run.bat for one-command setup
- [ ] Automated tests (risk engine, RSS parser, CVE client, auth)

## License

MIT — see [LICENSE](LICENSE).

---

Designed & built by **Subir Datta**.
